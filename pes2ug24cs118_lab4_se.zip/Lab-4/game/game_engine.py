import random
import pygame
from game.player import Player
from game.world import generate_platforms, draw_lava, PLATFORM_COLOR

WIDTH,HEIGHT=500,640
FPS=60
BG=(20,15,30)
GROUND_Y=HEIGHT+200

BASE_RISE = 0.4            # starting lava speed
MAX_RISE = 1.2             # normal top lava speed
BURST_INTERVAL_SEC = 15    # a burst every 15 seconds (set to 5 for quick testing)
BURST_DURATION_SEC = 3     # each burst lasts 3 seconds
BURST_MULTIPLIER = 2.5     # lava speed multiplier during a burst

class GameEngine:
    def __init__(self):
        pygame.init()
        self.screen=pygame.display.set_mode((WIDTH,HEIGHT))
        pygame.display.set_caption("Lava Escape")
        self.clock=pygame.time.Clock()
        self.font=pygame.font.SysFont("monospace",24,bold=True)
        self.small_font=pygame.font.SysFont("monospace",18,bold=True)
        self.big_font=pygame.font.SysFont("monospace",42,bold=True)
        self.reset()

    def reset(self):
        self.platforms=generate_platforms(WIDTH,GROUND_Y)
        self.player=Player(WIDTH//2-16,GROUND_Y-50)
        self.cam_y=0
        self.lava_y=GROUND_Y+60
        self.lava_rise=BASE_RISE
        self.burst_timer=0          # frames left in the current lava burst
        self.score=0
        self.game_over=False
        self.won=False
        self.top_y=self.platforms[-1].y
        self.frame=0

    def handle_events(self):
        for event in pygame.event.get():
            if event.type==pygame.QUIT: return False
            if event.type==pygame.KEYDOWN and event.key==pygame.K_r: self.reset()
        return True

    def update(self):
        if self.game_over or self.won: return
        keys=pygame.key.get_pressed()
        self.player.update(keys,self.platforms,WIDTH)

        # count down crumbling platforms and spring animations, remove crumbled platforms
        for p in self.platforms:
            if p.kind == "crumble" and p.crumble_timer is not None:
                p.crumble_timer -= 1
            if p.spring_timer > 0:
                p.spring_timer -= 1
        self.platforms = [p for p in self.platforms
                          if not (p.kind == "crumble" and p.crumble_timer is not None and p.crumble_timer <= 0)]

        target=self.player.rect.centery-HEIGHT//2
        if target<self.cam_y: self.cam_y=target

        # lava burst: every BURST_INTERVAL_SEC seconds, speed up for BURST_DURATION_SEC seconds
        if self.frame > 0 and self.frame % (BURST_INTERVAL_SEC * FPS) == 0:
            self.burst_timer = BURST_DURATION_SEC * FPS
        speed = self.lava_rise
        if self.burst_timer > 0:
            speed *= BURST_MULTIPLIER
            self.burst_timer -= 1

        self.lava_y-=speed
        self.lava_rise=min(MAX_RISE,self.lava_rise+0.0003)
        self.score=max(0,(GROUND_Y-self.player.rect.y)//10)
        self.frame+=1
        if self.player.rect.bottom>=self.lava_y:
            self.game_over=True
        if self.player.rect.top<=self.top_y-20:
            self.won=True

    def draw_danger_meter(self):
        bursting = self.burst_timer > 0
        # meter fills as lava_rise goes from BASE_RISE up to MAX_RISE; full during a burst
        fill = (self.lava_rise - BASE_RISE) / (MAX_RISE - BASE_RISE)
        if bursting:
            fill = 1.0
        fill = max(0.0, min(1.0, fill))

        speed = self.lava_rise * (BURST_MULTIPLIER if bursting else 1)
        label = self.small_font.render(f"DANGER  lava speed {speed:.1f}", True, (220,200,180))
        self.screen.blit(label, (8, 42))

        x, y, w, h = 8, 66, 220, 16
        pygame.draw.rect(self.screen, (50,40,60), (x, y, w, h), border_radius=4)
        # colour goes green -> yellow -> red as danger rises
        color = (int(80 + 175*fill), int(220 - 160*fill), 60)
        pygame.draw.rect(self.screen, color, (x, y, int(w*fill), h), border_radius=4)
        pygame.draw.rect(self.screen, (220,200,180), (x, y, w, h), 2, border_radius=4)

        if bursting and (self.frame // 8) % 2 == 0:      # flashing warning
            warn = self.big_font.render("LAVA BURST!", True, (255,80,40))
            self.screen.blit(warn, (WIDTH//2 - warn.get_width()//2, 100))

    def draw(self):
        self.screen.fill(BG)
        for p in self.platforms:
            dr = pygame.Rect(p.x, p.y - int(self.cam_y), p.width, p.height)
            color = PLATFORM_COLOR
            if p.kind == "crumble":
                color = (150,110,60)              # lighter brown = unstable
                if p.crumble_timer is not None:   # already stepped on
                    dr.x += random.randint(-3,3)  # shake
                    color = (200,90,50)           # turns reddish
            elif p.kind == "spring":
                color = (245,210,40)              # yellow spring platform
                if p.spring_timer > 0:            # recoil: squash down, then bounce back
                    squash = int(6 * p.spring_timer / 12)
                    dr.y += squash
                    dr.height -= squash
                    color = (255,235,90)          # flash brighter
            pygame.draw.rect(self.screen,color,dr,border_radius=4)
        self.player.draw(self.screen,self.cam_y)
        draw_lava(self.screen,self.lava_y,self.cam_y,WIDTH,HEIGHT,self.frame)
        sc=self.font.render(f"Height: {self.score}m  R=Restart",True,(220,200,180))
        self.screen.blit(sc,(8,10))
        self.draw_danger_meter()
        if self.game_over:
            self._msg("LAVA GOT YOU!",(220,80,40))
        if self.won:
            self._msg("ESCAPED!",(80,220,100))
        pygame.display.flip()

    def _msg(self,text,color):
        ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
        ov.fill((0,0,0,150))
        self.screen.blit(ov,(0,0))
        m=self.big_font.render(text,True,color)
        s=self.font.render("Press R to Play Again",True,(200,200,200))
        self.screen.blit(m,(WIDTH//2-m.get_width()//2,HEIGHT//2-40))
        self.screen.blit(s,(WIDTH//2-s.get_width()//2,HEIGHT//2+20))

    def run(self):
        running=True
        while running:
            running=self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        pygame.quit()
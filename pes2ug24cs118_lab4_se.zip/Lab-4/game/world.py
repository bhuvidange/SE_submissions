import pygame
import random

PLATFORM_COLOR = (100,80,50)
LAVA_COLOR = (220,60,20)

class Platform(pygame.Rect):
    """A Rect that also remembers what kind of platform it is."""
    kind = "normal"          # "normal", "crumble" or "spring"
    crumble_timer = None     # None = untouched, otherwise frames left
    spring_timer = 0         # frames left of the recoil animation

def generate_platforms(width, base_y, count=30):
    plats = [Platform(0, base_y, width, 20)]  # ground (always normal)
    y = base_y - 110
    for i in range(count):
        w = random.randint(80,200)
        x = random.randint(0, width-w)
        p = Platform(x, y, w, 16)
        # never make the last (top) platform special, since it is the win platform
        if i < count - 1:
            r = random.random()
            if r < 0.20:
                p.kind = "crumble"
            elif r < 0.35:
                p.kind = "spring"
        plats.append(p)
        y -= random.randint(80,130)
    return plats

def draw_lava(screen, lava_y, cam_y, width, height, frame):
    import math
    ly = int(lava_y - cam_y)
    if ly < height:
        # lava surface wave
        pts=[(0,ly)]
        for x in range(0,width+20,20):
            pts.append((x, ly + int(math.sin(x*0.08+frame*0.1)*8)))
        pts.append((width,height)); pts.append((0,height))
        pygame.draw.polygon(screen,LAVA_COLOR,pts)
        # glow
        s=pygame.Surface((width,30),pygame.SRCALPHA)
        for i in range(15):
            pygame.draw.line(s,(255,100,0,max(0,60-i*4)),(0,i),(width,i),1)
        screen.blit(s,(0,ly-15))
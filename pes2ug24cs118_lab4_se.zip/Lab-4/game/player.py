import pygame

SPEED = 4
SPRING_VELOCITY = -22

class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 32, 32)
        self.vel_y = 0
        self.on_ground = False
        self.color = (60,160,220)

    def update(self, keys, platforms, width):
        dx = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx = -SPEED
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx = SPEED
        if (keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]) and self.on_ground:
            self.vel_y = -13
            self.on_ground = False

        self.vel_y = min(self.vel_y + 0.55, 12)
        self.rect.x = max(0, min(width - self.rect.width, self.rect.x + dx))

        prev_bottom = self.rect.bottom      # feet position BEFORE moving this frame
        self.rect.y += int(self.vel_y)

        self.on_ground = False
        for p in platforms:
            if (self.vel_y > 0                          # falling
                    and self.rect.colliderect(p)        # overlapping the platform
                    and prev_bottom <= p.top + 2):      # feet were above the top edge before moving
                self.rect.bottom = p.top
                if p.kind == "spring":
                    self.vel_y = SPRING_VELOCITY        # launch with double jump velocity
                    p.spring_timer = 12                 # start the recoil animation
                    self.on_ground = False              # in the air, so no normal jump overrides it
                else:
                    self.vel_y = 0
                    self.on_ground = True
                if p.kind == "crumble" and p.crumble_timer is None:
                    p.crumble_timer = 60                # start the 1-second countdown

    def draw(self, screen, cam_y):
        dr = self.rect.move(0, -int(cam_y))
        pygame.draw.rect(screen, self.color, dr, border_radius=6)
        pygame.draw.circle(screen,(255,220,180),(dr.centerx, dr.top+8),7)